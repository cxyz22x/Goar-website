const CACHE_NAME = "goarxyz-shell-v6";
const APP_SHELL = [
  "/",
  "/index.html",
  "/assets/goarxyz-production.css",
  "/assets/goarxyz-production.js",
  "/assets/goarxyz-enhancements.css",
  "/assets/goarxyz-enhancements.js",
  "/assets/goarxyz-design.css",
  "/assets/goarxyz-design.js",
  "/assets/app-boot.js",
  "/assets/goarxyz-transport.js",
  "/assets/goarxyz-wisp.js",
  "/manifest.webmanifest",
  "/pwa-icon.svg",
  "/favicon.svg"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const network = fetch(event.request)
        .then((response) => {
          if (response.ok && event.request.destination !== "document") {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return response;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});
