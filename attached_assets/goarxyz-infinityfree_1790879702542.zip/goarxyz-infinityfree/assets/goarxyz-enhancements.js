(function () {
  "use strict";

  var catalog = null;
  var catalogPromise = null;
  var gamesMounted = false;
  var utilityMountedPath = "";
  var installPrompt = null;
  var supportEmail = "goarxyz@gmail.com";
  var gamesState = {
    provider: "all",
    query: "",
    limit: 72,
  };

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function logoMarkup() {
    return [
      '<span class="goar-brand" aria-label="goarxyz">',
      '<span class="goar-brand-white">goar</span>',
      '<span class="goar-brand-orange">x</span>',
      '<span class="goar-brand-green">y</span>',
      '<span class="goar-brand-purple">z</span>',
      '<span class="goar-brand-symbols" aria-hidden="true">△○✕□</span>',
      "</span>",
    ].join("");
  }

  function enhanceBranding() {
    var headerBrand = document.querySelector('header a[href="/"]');
    if (headerBrand && headerBrand.dataset.goarBrand !== "true") {
      headerBrand.dataset.goarBrand = "true";
      headerBrand.innerHTML = logoMarkup();
    }

    document.querySelectorAll("main h1").forEach(function (heading) {
      if (
        heading.textContent.trim() === "goarxyz" &&
        heading.dataset.goarBrand !== "true"
      ) {
        heading.dataset.goarBrand = "true";
        heading.innerHTML = logoMarkup();
      }
    });

    document.querySelectorAll("footer span").forEach(function (span) {
      if (
        span.dataset.goarBrand !== "true" &&
        span.textContent.trim().indexOf("goarxyz") === 0
      ) {
        span.dataset.goarBrand = "true";
        span.innerHTML = logoMarkup() + " · Entertainment Hub";
      }
    });
  }

  function enhanceHome() {
    var heading = Array.from(document.querySelectorAll("main h1")).find(
      function (node) {
        return (
          node.querySelector(".goar-brand") ||
          node.textContent.replace(/[△○✕□]/g, "").trim() === "goarxyz"
        );
      },
    );
    var shell = heading && heading.closest(".min-h-screen");
    if (!shell) return;
    shell.classList.add("goar-home-enhanced");
  }

  function currentPath() {
    return window.location.pathname.replace(/\/+$/, "") || "/";
  }

  function featuredAnime() {
    return [
      {
        title: "Top Anime",
        subtitle: "Discover the stories everyone is watching.",
        cover:
          "https://s4.anilist.co/file/anilistcdn/media/anime/cover/medium/bx1-GCsPm7waJ4kS.png",
      },
      {
        title: "Season picks",
        subtitle: "Fresh seasonal releases from AniList.",
        cover:
          "https://s4.anilist.co/file/anilistcdn/media/anime/cover/medium/bx20-dE6UHbFFg1A5.jpg",
      },
      {
        title: "Fan favourites",
        subtitle: "Popular series ready for a watch session.",
        cover:
          "https://s4.anilist.co/file/anilistcdn/media/anime/cover/medium/bx16498-buvcRTBx4NSm.jpg",
      },
      {
        title: "Browse the catalog",
        subtitle: "Search, save and watch through third-party sites.",
        cover:
          "https://s4.anilist.co/file/anilistcdn/media/anime/cover/medium/bx11061-y5gsT1hoHuHw.png",
      },
    ];
  }

  function homeExperienceShell() {
    return [
      '<section class="goar-home-extra" aria-labelledby="goar-home-now">',
      '<div class="goar-home-extra-heading">',
      '<div><p class="goar-eyebrow">THE MEDIA CENTRE</p><h2 id="goar-home-now">What are you into?</h2><p>Pick a lane, keep something playing, and come back whenever you want.</p></div>',
      '<button class="goar-install-button" data-goar-install hidden type="button">Install goarxyz</button>',
      "</div>",
      '<div class="goar-video-grid">',
      '<article class="goar-video-card goar-video-games">',
      '<div class="goar-video-heading"><span class="goar-video-kicker">TOP GAMES / PLAY LIVE</span><a href="/games">Open game library →</a></div>',
      '<div class="goar-video-frame goar-live-game-frame"><iframe data-goar-home-game-frame title="Top HTML5 game preview" src="https://games.cdn.famobi.com/html5games/c/cooking-blast/v020/?fg_domain=play.famobi.com&amp;fg_aid=A1000-1&amp;fg_uid=b3df1b60-8ce0-4316-bafb-bb79e84a1c36&amp;fg_pid=4638e320-4444-4514-81c4-d80a8c662371&amp;fg_npa=1" loading="lazy" allow="autoplay; gamepad; keyboard-map; fullscreen; picture-in-picture"></iframe></div>',
      '<div class="goar-video-caption"><strong>Play, then explore.</strong><span>A live preview of a top browser title, with no install required.</span></div>',
      "</article>",
      '<article class="goar-video-card goar-video-anime">',
      '<div class="goar-video-heading"><span class="goar-video-kicker">TOP ANIME / TRAILER</span><a href="/anime">Open anime catalog →</a></div>',
      '<div class="goar-video-frame goar-video-poster" style="background-image:url(https://img.youtube.com/vi/RIyb52EMx8c/maxresdefault.jpg)"><a href="https://www.youtube.com/watch?v=RIyb52EMx8c" target="_blank" rel="noopener noreferrer"><span class="goar-video-play">▶</span><strong>Watch trailer on YouTube</strong></a></div>',
      '<div class="goar-video-caption"><strong>Stay in the loop.</strong><span>Trailer discovery powered by YouTube and the anime catalog.</span></div>',
      "</article>",
      "</div>",
      '<div class="goar-home-section-heading"><div><p class="goar-eyebrow">CURATED FOR YOU</p><h2>Top games</h2></div><a href="/games">See all 1,338 titles →</a></div>',
      '<div class="goar-home-game-rail" data-goar-home-games><div class="goar-home-loading">Loading the library…</div></div>',
      '<div class="goar-home-section-heading"><div><p class="goar-eyebrow">WATCH NEXT</p><h2>Anime picks</h2></div><a href="/anime">Browse Anime →</a></div>',
      '<div class="goar-home-anime-rail">',
      featuredAnime().map(function (anime) {
        return '<a class="goar-home-anime-card" href="/anime"><img loading="lazy" src="' + anime.cover + '" alt=""><span><strong>' + anime.title + '</strong><small>' + anime.subtitle + '</small></span></a>';
      }).join(""),
      "</div>",
      '<div class="goar-home-service-grid">',
      '<article class="goar-service-card goar-support-card"><span class="goar-service-icon">?</span><div><p class="goar-eyebrow">NEED A HAND?</p><h2>Contact support</h2><p>Report a broken link, share feedback, or ask about the library.</p><a href="/support">Open support centre →</a></div></article>',
      '<article class="goar-service-card goar-ad-card"><span class="goar-service-icon">+</span><div><p class="goar-eyebrow">PARTNER WITH US</p><h2>Your brand here</h2><p>Reach people looking for something to play, watch, or listen to.</p><a href="mailto:' + supportEmail + '?subject=Advertise%20on%20goarxyz">Advertise here →</a></div></article>',
      "</div>",
      '<div class="goar-disclaimer"><strong>About this service</strong><p>goarxyz is an independent entertainment interface. We do not claim ownership of third-party games, music, anime, artwork, videos, or other content. Leisure content is accessed through third-party APIs, providers, and embeds. Rights remain with their respective owners.</p><div><a href="/privacy">Privacy</a><a href="/terms">Terms</a><a href="/support">Support</a></div></div>',
      "</section>",
    ].join("");
  }

  function mountHomeExperience() {
    var heading = Array.from(document.querySelectorAll("main h1")).find(function (node) {
      return node.querySelector(".goar-brand") || node.textContent.replace(/[△○✕□]/g, "").trim() === "goarxyz";
    });
    var shell = heading && heading.closest(".min-h-screen");
    if (!shell || shell.querySelector(".goar-home-extra")) return;
    shell.insertAdjacentHTML("beforeend", homeExperienceShell());
    var rail = shell.querySelector("[data-goar-home-games]");
    loadCatalog().then(function (games) {
      var gameFrame = shell.querySelector("[data-goar-home-game-frame]");
      if (gameFrame && games[0] && (games[0].file || games[0].itemUrl)) {
        gameFrame.src = games[0].file || games[0].itemUrl;
      }
      rail.innerHTML = games.slice(0, 8).map(function (game) {
        return [
          '<button type="button" class="goar-home-game-card" data-game-id="', escapeHtml(game.id), '">',
          '<img loading="lazy" src="', escapeHtml(game.cover), '" alt="">',
          "<span><strong>", escapeHtml(game.title), "</strong><small>", escapeHtml(game.provider === "marketjs" ? "MarketJS" : "Famobi"), "</small></span>",
          "</button>",
        ].join("");
      }).join("");
      rail.addEventListener("click", function (event) {
        var card = event.target.closest("[data-game-id]");
        if (!card) return;
        var game = games.find(function (item) { return item.id === card.dataset.gameId; });
        if (game) openGame(game);
      });
    }).catch(function () {
      rail.innerHTML = '<div class="goar-home-loading">The game library is temporarily unavailable.</div>';
    });
    shell.querySelectorAll("[data-goar-install]").forEach(function (button) {
      button.addEventListener("click", installApp);
    });
  }

  function installApp() {
    if (installPrompt) {
      installPrompt.prompt();
      installPrompt.userChoice.then(function () { installPrompt = null; });
      return;
    }
    window.alert("To install goarxyz, use your browser menu and choose “Add to Home Screen”.");
  }

  function utilityPageShell(path) {
    var isSupport = path === "/support";
    var isPrivacy = path === "/privacy";
    var title = isSupport ? "Contact support" : isPrivacy ? "Privacy centre" : "Terms & use";
    var eyebrow = isSupport ? "WE ARE HERE TO HELP" : isPrivacy ? "PLAIN-LANGUAGE PRIVACY" : "PLEASE READ";
    var body = isSupport
      ? '<p class="goar-utility-lead">Tell us what happened and your email app will open with the details ready to send.</p><form class="goar-support-form" data-goar-support-form><label>Your email<input type="email" name="email" required placeholder="you@example.com"></label><label>How can we help?<select name="topic"><option>Broken game or video</option><option>Content or copyright concern</option><option>Feedback and suggestions</option><option>Advertising enquiry</option><option>Something else</option></select></label><label>Message<textarea name="message" required rows="7" placeholder="Give us the useful details…"></textarea></label><button type="submit">Prepare support email →</button><p class="goar-form-status" data-goar-form-status></p></form><div class="goar-utility-note"><strong>Direct email</strong><a href="mailto:' + supportEmail + '">' + supportEmail + '</a></div>'
      : isPrivacy
        ? '<p class="goar-utility-lead">The short version: this static site does not fingerprint you or sell your data.</p><div class="goar-policy-copy"><h2>What we collect</h2><p>goarxyz stores only the preferences needed for the interface, such as whether you dismissed the install or analytics notice. Optional analytics is local, consent-based, and does not send browsing histories to a tracking network.</p><h2>Third-party services</h2><p>Games, music, anime metadata, artwork, and video embeds may load from third-party providers. Their own privacy policies and cookies can apply when you open or play content.</p><h2>Your choices</h2><p>You can decline optional analytics, clear site data in your browser, block third-party embeds, or contact us about a concern.</p></div>'
        : '<p class="goar-utility-lead">goarxyz is a discovery interface for leisure content, not a content owner or hosting service.</p><div class="goar-policy-copy"><h2>Content notice</h2><p>We do not claim ownership of third-party games, music, anime, artwork, videos, or other content. Content is accessed through third-party APIs, providers, and embeds. Rights remain with their respective owners.</p><h2>Acceptable use</h2><p>Use the site lawfully, respect provider terms, and do not attempt to disrupt, scrape, bypass access controls, or misuse embedded services.</p><h2>Availability</h2><p>Third-party links and embeds can change or become unavailable. goarxyz does not guarantee uptime, availability, or suitability of external content.</p></div>';
    return '<section class="goar-utility-page" data-goar-utility><div class="goar-utility-header"><p class="goar-eyebrow">' + eyebrow + '</p><h1>' + title + '</h1>' + body + '</div><div class="goar-utility-links"><a href="/">← Back to home</a><a href="/privacy">Privacy</a><a href="/terms">Terms</a><a href="/support">Support</a></div></section>';
  }

  function mountUtilityPage() {
    var path = currentPath();
    if (["/support", "/privacy", "/terms"].indexOf(path) === -1) {
      utilityMountedPath = "";
      return;
    }
    var main = document.querySelector("main");
    if (!main || utilityMountedPath === path) return;
    utilityMountedPath = path;
    main.classList.add("goar-utility-main");
    main.innerHTML = utilityPageShell(path);
    var form = main.querySelector("[data-goar-support-form]");
    if (form) {
      form.addEventListener("submit", function (event) {
        event.preventDefault();
        var data = new FormData(form);
        var subject = encodeURIComponent("goarxyz support — " + data.get("topic"));
        var body = encodeURIComponent("From: " + data.get("email") + "\n\n" + data.get("message"));
        window.location.href = "mailto:" + supportEmail + "?subject=" + subject + "&body=" + body;
        main.querySelector("[data-goar-form-status]").textContent = "Your email app should open with the message prepared.";
      });
    }
  }

  function enhanceFooter() {
    var footer = document.querySelector("footer");
    if (!footer || footer.querySelector("[data-goar-footer-links]")) return;
    var links = document.createElement("div");
    links.dataset.goarFooterLinks = "true";
    links.className = "goar-footer-links";
    links.innerHTML = '<a href="/support">Support</a><a href="/privacy">Privacy</a><a href="/terms">Terms</a><a href="mailto:' + supportEmail + '?subject=Advertise%20on%20goarxyz">Advertise here</a><button type="button" data-goar-install hidden>Install app</button>';
    footer.appendChild(links);
    links.querySelector("[data-goar-install]").addEventListener("click", installApp);
  }

  function mountAnalyticsNotice() {
    if (document.querySelector("[data-goar-analytics-notice]")) return;
    var choice = null;
    try { choice = localStorage.getItem("goarxyz-analytics-consent"); } catch (error) {}
    if (choice) return;
    var notice = document.createElement("aside");
    notice.className = "goar-consent";
    notice.dataset.goarAnalyticsNotice = "true";
    notice.innerHTML = '<div><strong>Your privacy matters</strong><p>Optional, local-only analytics helps us understand which sections are useful. No fingerprinting, ad trackers, or sale of personal data.</p></div><div><button type="button" data-goar-consent="decline">Decline</button><button type="button" data-goar-consent="accept">Allow local analytics</button></div>';
    document.body.appendChild(notice);
    notice.addEventListener("click", function (event) {
      var button = event.target.closest("[data-goar-consent]");
      if (!button) return;
      try { localStorage.setItem("goarxyz-analytics-consent", button.dataset.goarConsent); } catch (error) {}
      notice.remove();
    });
  }

  function recordLocalPageView() {
    var choice = null;
    try { choice = localStorage.getItem("goarxyz-analytics-consent"); } catch (error) {}
    if (choice !== "accept") return;
    try {
      var views = JSON.parse(localStorage.getItem("goarxyz-local-analytics") || "[]");
      views.push({ path: currentPath(), at: new Date().toISOString() });
      localStorage.setItem("goarxyz-local-analytics", JSON.stringify(views.slice(-50)));
    } catch (error) {}
  }

  function isGamesPage() {
    return Array.from(document.querySelectorAll("main h1")).some(function (node) {
      return node.textContent.trim() === "Games";
    });
  }

  function loadCatalog() {
    if (catalogPromise) return catalogPromise;
    catalogPromise = fetch((function(){
      var b = document.querySelector("base");
      var root = (b && b.href) ? b.href : (location.origin + location.pathname.replace(/\/(games|music|anime)(\/.*)?$/, "/").replace(/[^/]+\.[a-z]+$/, ""));
      if (!/\/$/.test(root)) root += "/";
      return root + "data/game-catalog.json";
    })(), { cache: "force-cache" })
      .then(function (response) {
        if (!response.ok) throw new Error("Game catalog could not be loaded.");
        return response.json();
      })
      .then(function (payload) {
        catalog = Array.isArray(payload.games) ? payload.games : [];
        return catalog;
      });
    return catalogPromise;
  }

  function providerLabel(provider) {
    return provider === "marketjs" ? "MarketJS demo" : "Famobi wrapper";
  }

  function filteredGames() {
    if (!catalog) return [];
    var query = gamesState.query.trim().toLowerCase();
    return catalog.filter(function (game) {
      var matchesQuery =
        !query ||
        [game.title, game.description, game.category, game.provider]
          .join(" ")
          .toLowerCase()
          .indexOf(query) !== -1;
      var matchesProvider =
        gamesState.provider === "all" || game.provider === gamesState.provider;
      return matchesQuery && matchesProvider;
    });
  }

  function gameCard(game) {
    var providerClass =
      game.provider === "marketjs"
        ? "goar-game-card-market"
        : "goar-game-card-famobi";
    return [
      '<article class="goar-game-card ',
      providerClass,
      '">',
      '<button type="button" class="goar-game-card-button" data-game-id="',
      escapeHtml(game.id),
      '">',
      '<div class="goar-game-cover">',
      '<img loading="lazy" src="',
      escapeHtml(game.cover),
      '" alt="" onerror="this.classList.add(\'is-missing\')">',
      '<span class="goar-game-provider">',
      escapeHtml(providerLabel(game.provider)),
      "</span>",
      "</div>",
      '<div class="goar-game-copy">',
      '<h3>',
      escapeHtml(game.title),
      "</h3>",
      '<p>',
      escapeHtml(game.description),
      "</p>",
      "</div>",
      "</button>",
      "</article>",
    ].join("");
  }

  function renderCatalog(root) {
    var games = filteredGames();
    var visible = games.slice(0, gamesState.limit);
    var famobiCount = catalog.filter(function (game) {
      return game.provider === "famobi";
    }).length;
    var marketCount = catalog.filter(function (game) {
      return game.provider === "marketjs";
    }).length;

    var grid = root.querySelector("[data-goar-games-grid]");
    var loadMore = root.querySelector("[data-goar-load-more]");
    var resultCounts = root.querySelectorAll("[data-goar-result-count]");
    if (!grid || !resultCounts.length || !loadMore) return;

    resultCounts.forEach(function (resultCount) {
      resultCount.textContent =
        games.length + (games.length === 1 ? " title" : " titles");
    });
    grid.innerHTML = visible.length
      ? visible.map(gameCard).join("")
      : '<div class="goar-games-empty"><strong>No games found</strong><span>Try a different search or provider.</span></div>';
    loadMore.hidden = visible.length >= games.length;
    loadMore.textContent =
      "Load more · " + Math.min(games.length - visible.length, 72);

    root.querySelectorAll("[data-goar-provider]").forEach(function (button) {
      var provider = button.dataset.goarProvider;
      button.classList.toggle("is-active", provider === gamesState.provider);
    });
    root.querySelector('[data-goar-provider="famobi"] .goar-filter-count').textContent =
      famobiCount;
    root.querySelector('[data-goar-provider="marketjs"] .goar-filter-count').textContent =
      marketCount;
  }

  function openGame(game) {
    var existing = document.querySelector("[data-goar-game-overlay]");
    if (existing) existing.remove();

    var overlay = document.createElement("div");
    overlay.dataset.goarGameOverlay = "true";
    overlay.className = "goar-game-overlay";
    overlay.innerHTML = [
      '<div class="goar-game-overlay-bar">',
      '<div class="goar-game-overlay-title">',
      '<span class="goar-game-overlay-provider">',
      escapeHtml(providerLabel(game.provider)),
      "</span>",
      "<strong>",
      escapeHtml(game.title),
      "</strong>",
      "</div>",
      '<button type="button" class="goar-game-close" aria-label="Close game">×</button>',
      "</div>",
      '<div class="goar-game-frame-wrap">',
      '<iframe title="',
      escapeHtml(game.title),
      '" src="',
      escapeHtml(game.file || game.itemUrl),
      '" allow="autoplay; gamepad; keyboard-map; fullscreen; picture-in-picture; accelerometer; gyroscope; clipboard-write" allowfullscreen referrerpolicy="strict-origin-when-cross-origin" sandbox="allow-scripts allow-same-origin allow-forms allow-pointer-lock allow-modals allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation allow-downloads allow-orientation-lock"></iframe>',
      "</div>",
    ].join("");

    function close() {
      document.removeEventListener("keydown", onKey);
      document.body.classList.remove("goar-game-open");
      overlay.remove();
    }
    function onKey(event) {
      if (event.key === "Escape") close();
    }

    overlay.querySelector(".goar-game-close").addEventListener("click", close);
    overlay.addEventListener("click", function (event) {
      if (event.target === overlay) close();
    });
    document.addEventListener("keydown", onKey);
    document.body.classList.add("goar-game-open");
    document.body.appendChild(overlay);
  }

  function gamesShell() {
    return [
      '<section class="goar-games-app" aria-labelledby="goar-games-heading">',
      '<div class="goar-games-intro">',
      '<div>',
      '<p class="goar-eyebrow">INSTANT PLAY / GAME LIBRARY</p>',
      '<h1 id="goar-games-heading">Games</h1>',
      '<p class="goar-games-lead">Instant HTML5 titles · no install · play directly in your browser.</p>',
      "</div>",
      '<div class="goar-games-stats">',
      '<strong data-goar-result-count>Loading titles…</strong>',
      "<span>available to play</span>",
      "</div>",
      "</div>",
      '<div class="goar-games-controls">',
      '<label class="goar-game-search"><span aria-hidden="true">⌕</span><input data-goar-search type="search" placeholder="Search the full library…" autocomplete="off"></label>',
      '<div class="goar-provider-filters" role="group" aria-label="Filter by provider">',
      '<button type="button" class="is-active" data-goar-provider="all">All providers <span class="goar-filter-count">1,338</span></button>',
      '<button type="button" data-goar-provider="famobi">Famobi <span class="goar-filter-count">648</span></button>',
      '<button type="button" data-goar-provider="marketjs">MarketJS <span class="goar-filter-count">690</span></button>',
      "</div>",
      "</div>",
      '<div class="goar-games-meta"><span>Choose a title to open its original provider demo.</span><span data-goar-result-count>Loading titles…</span></div>',
      '<div class="goar-games-grid" data-goar-games-grid></div>',
      '<button type="button" class="goar-load-more" data-goar-load-more>Load more</button>',
      "</section>",
    ].join("");
  }

  function mountGames() {
    if (gamesMounted || !isGamesPage()) return;
    var main = document.querySelector("main");
    if (!main) return;
    gamesMounted = true;
    main.classList.add("goar-games-main");
    main.innerHTML = gamesShell();
    var root = main.querySelector(".goar-games-app");
    var search = root.querySelector("[data-goar-search]");
    var loadMore = root.querySelector("[data-goar-load-more]");

    root.addEventListener("click", function (event) {
      var provider = event.target.closest("[data-goar-provider]");
      if (provider) {
        gamesState.provider = provider.dataset.goarProvider;
        gamesState.limit = 72;
        renderCatalog(root);
        return;
      }
      var card = event.target.closest("[data-game-id]");
      if (card && catalog) {
        var game = catalog.find(function (item) {
          return item.id === card.dataset.gameId;
        });
        if (game) openGame(game);
      }
    });
    search.addEventListener("input", function () {
      gamesState.query = search.value;
      gamesState.limit = 72;
      renderCatalog(root);
    });
    loadMore.addEventListener("click", function () {
      gamesState.limit += 72;
      renderCatalog(root);
    });

    loadCatalog()
      .then(function () {
        renderCatalog(root);
      })
      .catch(function () {
        root.querySelector("[data-goar-games-grid]").innerHTML =
          '<div class="goar-games-empty"><strong>Game library unavailable</strong><span>The local catalog could not be loaded.</span></div>';
      });
  }

  function routeScan() {
    enhanceBranding();
    enhanceFooter();
    mountUtilityPage();
    if (!["/support", "/privacy", "/terms"].includes(currentPath())) mountAnalyticsNotice();
    enhanceHome();
    mountHomeExperience();
    if (!isGamesPage()) gamesMounted = false;
    mountGames();
  }

  window.addEventListener("beforeinstallprompt", function (event) {
    event.preventDefault();
    installPrompt = event;
    document.querySelectorAll("[data-goar-install]").forEach(function (button) {
      button.hidden = false;
    });
  });
  var lastRecordedPath = "";
  setInterval(function () {
    if (lastRecordedPath !== currentPath()) {
      lastRecordedPath = currentPath();
      recordLocalPageView();
    }
  }, 1000);
  setTimeout(routeScan, 0);
  setTimeout(routeScan, 250);
  setTimeout(routeScan, 1000);
  setInterval(routeScan, 750);
})();