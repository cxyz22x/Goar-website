(function () {
  "use strict";

  function sectionFromPath(path) {
    if (/\/games(\/|$)/.test(path)) return "games";
    if (/\/music(\/|$)/.test(path)) return "music";
    if (/\/anime(\/|$)/.test(path)) return "anime";
    return "home";
  }

  function applySection() {
    var section = sectionFromPath(location.pathname);
    document.documentElement.dataset.section = section;
    if (document.body) document.body.dataset.section = section;
    var themes = { home: "#090909", games: "#e86a2a", music: "#1db954", anime: "#a855f7" };
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", section === "home" ? "#090909" : "#090909");
    document.documentElement.style.setProperty("--gx-active", themes[section] || themes.home);
  }

  function normalizePath() {
    var path = location.pathname;
    if (/\/(games|music|anime)\/index\.html$/.test(path)) {
      history.replaceState(null, "", path.replace(/\/index\.html$/, "/") + location.search + location.hash);
    }
  }

  function wrap(fn) {
    return function () {
      var result = fn.apply(this, arguments);
      applySection();
      return result;
    };
  }

  normalizePath();
  applySection();
  history.pushState = wrap(history.pushState);
  history.replaceState = wrap(history.replaceState);
  window.addEventListener("popstate", applySection);
  document.addEventListener("DOMContentLoaded", applySection);
})();
