(function (window, document) {
  "use strict";

  var bridge = window.__goarxyzWispBridge || {};
  window.__goarxyzWispBridge = bridge;
  if (!window.goarxyzWispReady) {
    window.goarxyzWispReady = new Promise(function (resolve, reject) {
      bridge.resolve = resolve;
      bridge.reject = reject;
    });
  }
  window.goarxyzWispStatus = window.goarxyzWispStatus || "connecting";

  var nativeFetch = window.fetch.bind(window);
  window.goarxyzNativeFetch = nativeFetch;

  var PIPED = [
    "https://pipedapi.kavin.rocks",
    "https://pipedapi.adminforge.de",
    "https://pipedapi.meox.dev",
    "https://api.piped.private.coffee"
  ];
  var INVIDIOUS = [
    "https://inv.nadeko.net",
    "https://invidious.f5.si",
    "https://yewtu.be",
    "https://invidious.nerdvpn.de",
    "https://iv.ggtyler.dev"
  ];
  var CORS_GET = [
    function (url) { return url; },
    function (url) { return "https://corsproxy.io/?" + encodeURIComponent(url); },
    function (url) { return "https://corsproxy.org/?" + encodeURIComponent(url); },
    function (url) { return "https://api.allorigins.win/raw?url=" + encodeURIComponent(url); }
  ];

  function hostOf(url) {
    try { return new URL(url, window.location.href).hostname; }
    catch (e) { return ""; }
  }

  function shouldTunnel(url) {
    var host = hostOf(url);
    if (!host) return false;
    if (host === window.location.hostname) return false;
    return /(?:^|\.)((pipedapi\.)|(invidious\.)|(inv\.)|yewtu\.be|graphql\.anilist\.co|s4\.anilist\.co|api\.jikan\.moe|corsproxy\.(io|org)|allorigins\.win|youtube\.com|youtu\.be|music\.youtube\.com|i\.ytimg\.com|ytimg\.com)$/.test(host) ||
      host.indexOf("pipedapi.") !== -1 ||
      host.indexOf("invidious.") !== -1 ||
      host === "inv.nadeko.net" ||
      host === "yewtu.be" ||
      host === "graphql.anilist.co" ||
      host === "api.jikan.moe" ||
      host.indexOf("corsproxy.") !== -1 ||
      host.indexOf("allorigins.win") !== -1 ||
      host.indexOf("youtube.com") !== -1 ||
      host.indexOf("ytimg.com") !== -1;
  }

  function siblingUrls(url) {
    var out = [url];
    try {
      var u = new URL(url, window.location.href);
      var path = u.pathname + u.search;
      var i, base, next;
      if (u.hostname.indexOf("pipedapi.") !== -1 || u.hostname.indexOf("piped.") !== -1) {
        for (i = 0; i < PIPED.length; i++) {
          next = PIPED[i] + path.replace(/^\/+/, "/");
          if (out.indexOf(next) === -1) out.push(next);
        }
      }
      if (u.hostname === "inv.nadeko.net" || u.hostname.indexOf("invidious.") !== -1 || u.hostname === "yewtu.be" || u.hostname.indexOf("iv.") === 0) {
        for (i = 0; i < INVIDIOUS.length; i++) {
          next = INVIDIOUS[i] + path.replace(/^\/+/, "/");
          if (out.indexOf(next) === -1) out.push(next);
        }
      }
    } catch (e) {}
    return out;
  }

  function timeoutMs(opts, fallback) {
    return (opts && opts.goarTimeout) || fallback || 12000;
  }

  window.goarxyzWispFetch = window.goarxyzWispFetch || function (url, opts, limit) {
    opts = opts || {};
    return Promise.race([
      window.goarxyzWispReady,
      new Promise(function (_, reject) {
        setTimeout(function () { reject(new Error("Wisp connection timed out")); }, timeoutMs(opts, limit || 12000));
      })
    ]).then(function (client) {
      if (client && typeof client.fetch === "function") {
        var headers = new Headers(opts.headers || {});
        return client.fetch(url, Object.assign({}, opts, {
          headers: Array.from(headers.entries()),
          maxRedirects: 8
        }));
      }
      if (typeof window.goarxyzWispFetch === "function" && window.goarxyzWispStatus === "ready") {
        return window.goarxyzWispFetch(url, opts, limit);
      }
      throw new Error("Wisp client missing");
    });
  };

  window.goarxyzFetchAny = async function (url, opts, limit) {
    opts = opts || {};
    var ms = timeoutMs(opts, limit || 14000);
    if (window.goarxyzWispFetch) {
      try {
        return await window.goarxyzWispFetch(url, opts, ms);
      } catch (err) {
        console.warn("[goarxyz] Wisp request failed; using fallback", err && err.message ? err.message : err);
      }
    }
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, ms);
    try {
      return await nativeFetch(url, Object.assign({}, opts, { signal: ctrl.signal }));
    } finally {
      clearTimeout(timer);
    }
  };

  window.goarxyzProxyFetch = async function (url, opts) {
    opts = opts || {};
    var last = new Error("proxy fetch failed");
    var chain = shouldTunnel(url) ? siblingUrls(url) : [url];
    var i, j, target, built, res;
    var builders = CORS_GET;
    for (i = 0; i < chain.length; i++) {
      target = chain[i];
      for (j = 0; j < builders.length; j++) {
        built = builders[j](target);
        try {
          res = await window.goarxyzFetchAny(built, opts, 14000);
          if (res && res.status === 429) {
            await new Promise(function (r) { setTimeout(r, 1200); });
            continue;
          }
          if (res && (res.ok || (res.status >= 300 && res.status < 500))) return res;
          last = new Error("HTTP " + (res && res.status));
        } catch (err) {
          last = err;
        }
      }
    }
    throw last;
  };

  function normalizePiped(items) {
    return (items || []).slice(0, 24).map(function (item) {
      var id = String(item.url || item.id || item.videoId || "")
        .replace("/watch?v=", "")
        .replace(/^\//, "");
      if (id.indexOf("v=") !== -1) id = id.split("v=")[1].slice(0, 11);
      return {
        id: id.slice(0, 11),
        title: item.title || item.name || "",
        artist: item.uploaderName || item.author || item.uploader || "YouTube"
      };
    }).filter(function (item) { return item.id.length === 11 && item.title; });
  }

  function normalizeInv(items) {
    return (Array.isArray(items) ? items : []).slice(0, 24).map(function (item) {
      return {
        id: String(item.videoId || item.id || "").slice(0, 11),
        title: item.title || "",
        artist: item.author || item.authorName || "YouTube"
      };
    }).filter(function (item) { return item.id.length === 11 && item.title; });
  }

  window.goarxyzMusicSearch = async function (query) {
    var q = String(query || "").trim();
    if (!q) return [];
    var tries = [];
    PIPED.forEach(function (base) {
      tries.push({ kind: "piped", url: base + "/search?q=" + encodeURIComponent(q) + "&filter=music_songs" });
      tries.push({ kind: "piped", url: base + "/search?q=" + encodeURIComponent(q) + "&filter=videos" });
    });
    INVIDIOUS.forEach(function (base) {
      tries.push({ kind: "inv", url: base + "/api/v1/search?type=video&region=US&q=" + encodeURIComponent(q) });
    });
    var i, spec, res, data, rows;
    for (i = 0; i < tries.length; i++) {
      spec = tries[i];
      try {
        res = await window.goarxyzProxyFetch(spec.url, { headers: { Accept: "application/json" } });
        if (!res || !res.ok) continue;
        data = await res.json();
        rows = spec.kind === "piped" ? normalizePiped(data.items || data) : normalizeInv(data);
        if (rows.length) {
          window.goarxyzLastMusicSource = spec.url;
          return rows;
        }
      } catch (err) {}
    }
    throw new Error("Music search unavailable");
  };

  window.goarxyzJikan = async function (path) {
    var url = "https://api.jikan.moe/v4" + (path.charAt(0) === "/" ? path : "/" + path);
    var res = await window.goarxyzProxyFetch(url, { headers: { Accept: "application/json" } });
    if (!res || !res.ok) throw new Error("Jikan HTTP " + (res && res.status));
    return res.json();
  };

  var patched = false;
  function patchFetch() {
    if (patched) return;
    patched = true;
    window.fetch = function (input, init) {
      var url = typeof input === "string" ? input : (input && input.url) || "";
      if (!url || !shouldTunnel(url)) return nativeFetch(input, init);
      return window.goarxyzProxyFetch(url, init || {});
    };
  }
  patchFetch();

  function paintStatus() {
    var el = document.getElementById("gx-transport");
    if (!el) {
      el = document.createElement("div");
      el.id = "gx-transport";
      el.className = "gx-transport";
      el.setAttribute("aria-live", "polite");
      document.body.appendChild(el);
    }
    var state = window.goarxyzWispStatus || "connecting";
    el.dataset.state = state;
    el.textContent = state === "ready" ? "Wisp live" : state === "error" ? "Direct fallback" : "Wisp…";
  }

  window.addEventListener("goarxyz:wisp-ready", function () {
    window.goarxyzWispStatus = "ready";
    paintStatus();
  });
  window.addEventListener("goarxyz:wisp-error", function () {
    window.goarxyzWispStatus = "error";
    paintStatus();
  });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", paintStatus);
  } else {
    paintStatus();
  }
  setTimeout(paintStatus, 2500);
})(window, document);
